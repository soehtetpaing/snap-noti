class Snowflake {
  constructor(workerId = 1, datacenterId = 1) {
    this.workerId = BigInt(workerId);
    this.datacenterId = BigInt(datacenterId);

    this.sequence = 0n;
    this.lastTimestamp = -1n;

    this.WORKER_ID_BITS = 5n;
    this.DATACENTER_ID_BITS = 5n;
    this.SEQUENCE_BITS = 12n;

    this.MAX_WORKER_ID = (1n << this.WORKER_ID_BITS) - 1n;
    this.MAX_DATACENTER_ID = (1n << this.DATACENTER_ID_BITS) - 1n;

    this.WORKER_ID_SHIFT = this.SEQUENCE_BITS;
    this.DATACENTER_ID_SHIFT = this.SEQUENCE_BITS + this.WORKER_ID_BITS;
    this.TIMESTAMP_SHIFT =
      this.SEQUENCE_BITS + this.WORKER_ID_BITS + this.DATACENTER_ID_BITS;

    this.SEQUENCE_MASK = (1n << this.SEQUENCE_BITS) - 1n;

    this.EPOCH = 1719187200000n; // June 24, 2024

    if (this.workerId > this.MAX_WORKER_ID || this.workerId < 0) {
      throw new Error("Invalid workerId");
    }
    if (this.datacenterId > this.MAX_DATACENTER_ID || this.datacenterId < 0) {
      throw new Error("Invalid datacenterId");
    }
  }

  currentTime() {
    return BigInt(Date.now());
  }

  waitNextMillis(lastTimestamp) {
    let timestamp = this.currentTime();
    while (timestamp <= lastTimestamp) {
      timestamp = this.currentTime();
    }
    return timestamp;
  }

  nextId() {
    let timestamp = this.currentTime();

    if (timestamp < this.lastTimestamp) {
      throw new Error("Clock moved backwards!");
    }

    if (timestamp === this.lastTimestamp) {
      this.sequence = (this.sequence + 1n) & this.SEQUENCE_MASK;

      if (this.sequence === 0n) {
        timestamp = this.waitNextMillis(this.lastTimestamp);
      }
    } else {
      this.sequence = 0n;
    }

    this.lastTimestamp = timestamp;

    return (
      ((timestamp - this.EPOCH) << this.TIMESTAMP_SHIFT) |
      (this.datacenterId << this.DATACENTER_ID_SHIFT) |
      (this.workerId << this.WORKER_ID_SHIFT) |
      this.sequence
    );
  }
}

export default Snowflake;
